#UBC EOAS Software Carpentry Bootcamp

##Files for Python Lessons


This repository contains the collection of files used in the live-coding and exercises of the Programming with Python section of the UBC EOAS Software Carpentry Bootcamp.

The intended use of the repo is to clone it as `hbridge` in the learners' `Desktop/swc/` directory.
